#!/bin/bash
# Push PRISM backup to GitHub after repo is created
# Run this AFTER you've created prism-backup repo on GitHub

set -e

REPO_DIR="/Users/anilgunjal/.openclaw/backup/prism-backup-repo"
BACKUP_DIR="/Users/anilgunjal/.openclaw/backup"

echo "🚀 Pushing PRISM backup to GitHub..."
echo ""

cd "$REPO_DIR"

# Add remote
git remote rm origin 2>/dev/null || true
git remote add origin "git@github.com:anil763/prism-backup.git"

# Copy latest backup
LATEST_BACKUP=$(ls -t "$BACKUP_DIR"/PRISM_BACKUP_*.tar.gz 2>/dev/null | head -1)
if [ -z "$LATEST_BACKUP" ]; then
  echo "❌ No backup found. Run the backup first."
  exit 1
fi

echo "📦 Latest backup: $(basename $LATEST_BACKUP)"

cp "$LATEST_BACKUP" .
git add "$(basename $LATEST_BACKUP)"
git commit -m "🔄 PRISM Backup $(date +%Y-%m-%d_%H-%M-%S)" || true

# Push
if git push -u origin main 2>&1; then
  echo ""
  echo "✅ Backup successfully pushed to GitHub!"
  echo ""
  echo "View at: https://github.com/anil763/prism-backup"
  echo ""
  echo "From now on, backups will push automatically every day at 5 AM."
  echo ""
else
  echo ""
  echo "❌ Push failed. Did you create the repo?"
  echo "   Go to https://github.com/new and create 'prism-backup' (private)"
  exit 1
fi
