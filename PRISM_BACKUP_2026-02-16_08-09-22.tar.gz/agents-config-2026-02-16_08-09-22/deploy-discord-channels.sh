#!/bin/bash
# Discord Channel Auto-Deployment Script
# Run this to create all 4 agent channels

BOT_TOKEN="MTQ3MjgwMzU3NTU3Nzk2ODc0MQ.GrWBlC.gi5uj2MsP0RUlNAp-RqdZw4hiGHeOiI9_O-rQ0"
SERVER_ID="1472794487934812173"

echo "🔮 PRISM Discord Channel Deployment"
echo "===================================="
echo ""

# Function to create channel
create_channel() {
  local name="$1"
  local topic="$2"
  
  echo "📍 Creating #$name..."
  
  response=$(curl -s -X POST "https://discord.com/api/guilds/$SERVER_ID/channels" \
    -H "Authorization: Bot $BOT_TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"name\": \"$name\", \"type\": 0, \"topic\": \"$topic\"}")
  
  channel_id=$(echo "$response" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)
  
  if [ -n "$channel_id" ]; then
    echo "   ✅ Created: $channel_id"
    echo "$name:$channel_id"
  else
    error=$(echo "$response" | grep -o '"message":"[^"]*"' | cut -d'"' -f4)
    echo "   ❌ Failed: $error"
  fi
}

# Create all 4 channels
echo ""
echo "Creating agent channels..."
echo ""

create_channel "ugc-opportunities" "UGC Email Agent (6 AM Mon-Fri) - Brand research & outreach"
create_channel "spiritual-business" "Spiritual Business Agent (7:30 AM) - Market trends & opportunities"
create_channel "ai-trends" "AI Trends Agent (8:00 AM) - Daily AI news & emerging tools"
create_channel "managed-services" "Managed Services Agent (8:30 AM) - Cloud/MSP competitive landscape"

echo ""
echo "✅ Deployment complete!"
echo ""
echo "Next: Update discord-channels.json with channel IDs once creation succeeds."
