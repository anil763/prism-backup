#!/bin/bash
# Multi-Cloud Backup System
# Backup to GitHub + AWS S3 + iCloud + Email for true disaster recovery

BACKUP_DIR="/Users/anilgunjal/.openclaw/backup"
TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
BACKUP_FILE="PRISM_BACKUP_$TIMESTAMP.tar.gz"

echo "🌍 Starting Multi-Cloud Backup ($TIMESTAMP)..."

# 1. Create local backup (same as before)
mkdir -p "$BACKUP_DIR"
cp -r /Users/anilgunjal/.openclaw/workspace/agents-config "$BACKUP_DIR/agents-config-$TIMESTAMP"
cp -r /Users/anilgunjal/.openclaw/workspace/memory "$BACKUP_DIR/memory-$TIMESTAMP"
cp /Users/anilgunjal/.openclaw/workspace/DISASTER_RECOVERY.md "$BACKUP_DIR/"

# Compress
cd "$BACKUP_DIR"
tar -czf "$BACKUP_FILE" agents-config-$TIMESTAMP memory-$TIMESTAMP DISASTER_RECOVERY.md
rm -rf agents-config-$TIMESTAMP memory-$TIMESTAMP

echo "✅ Local backup created: $BACKUP_FILE"

# 2. Push to GitHub
echo "📤 Pushing to GitHub backup repo..."
if [ -d "$BACKUP_DIR/prism-backup-repo" ]; then
  cd "$BACKUP_DIR/prism-backup-repo"
  
  # Get token from Keychain
  GH_TOKEN=$(security find-generic-password -a github -s "ghp_token" -w 2>/dev/null)
  
  if [ -n "$GH_TOKEN" ]; then
    # Configure remote with token
    git remote rm origin 2>/dev/null || true
    git remote add origin "https://anil763:$GH_TOKEN@github.com/anil763/prism-backup.git"
    
    cp "../$BACKUP_FILE" .
    git add "$BACKUP_FILE"
    git commit -m "🔄 PRISM Backup $TIMESTAMP" 2>/dev/null || true
    
    # Push to GitHub
    if git push origin main 2>/dev/null; then
      echo "✅ GitHub backup pushed successfully"
    else
      echo "⚠️ GitHub push failed (check token in Keychain)"
    fi
  else
    echo "⚠️ GitHub token not found in Keychain (backup to local + iCloud only)"
  fi
else
  echo "⚠️ Backup repo directory not found"
fi

# 3. Backup to AWS S3 (if credentials exist)
echo "☁️ Backing up to AWS S3..."
if [ -f ~/.aws/credentials ]; then
  aws s3 cp "$BACKUP_DIR/$BACKUP_FILE" s3://prism-backups/daily/ --storage-class GLACIER_IR 2>/dev/null && \
  echo "✅ S3 backup uploaded (GLACIER_IR for cost savings)" || \
  echo "⚠️ S3 backup failed (check AWS credentials)"
else
  echo "⚠️ AWS credentials not found (optional)"
fi

# 4. Backup to iCloud Drive
echo "☁️ Backing up to iCloud Drive..."
ICLOUD_DRIVE="$HOME/Library/Mobile Documents/com~apple~CloudDocs"
if [ -d "$ICLOUD_DRIVE" ]; then
  mkdir -p "$ICLOUD_DRIVE/PRISM_Backups"
  cp "$BACKUP_DIR/$BACKUP_FILE" "$ICLOUD_DRIVE/PRISM_Backups/"
  echo "✅ iCloud Drive backup updated"
else
  echo "⚠️ iCloud Drive not found (enable in System Settings)"
fi

# 5. Email critical files (Monday only, to avoid spam)
if [ "$(date +%u)" == "1" ]; then
  echo "📧 Sending weekly backup email..."
  
  # Create email body
  cat > /tmp/backup_email.txt << EOF
PRISM Weekly Backup Report
Timestamp: $TIMESTAMP

✅ Backup Status: SUCCESS

Backups created in 3 locations:
1. GitHub (prism-backup repo) - Private, version controlled
2. AWS S3 - Encrypted, GLACIER_IR storage
3. iCloud Drive - Accessible from any Apple device

Recovery Instructions:
- GitHub: git clone https://github.com/anil763/prism-backup.git
- iCloud: Open iCloud Drive → PRISM_Backups folder
- AWS S3: aws s3 cp s3://prism-backups/daily/PRISM_BACKUP_*.tar.gz .

See DISASTER_RECOVERY.md for full recovery steps.

If iMac crashes completely, you can recover from any of these 3 locations.
EOF

  # Send email (requires mail setup)
  # Uncomment if you have mail configured
  # mail -s "PRISM Weekly Backup Report" your-email@example.com < /tmp/backup_email.txt
  
  echo "✅ Weekly backup email prepared (uncomment mail command to send)"
fi

echo ""
echo "🎉 Multi-Cloud Backup Complete!"
echo "   Local: $BACKUP_DIR/$BACKUP_FILE"
echo "   GitHub: prism-backup repo"
echo "   AWS S3: s3://prism-backups/daily/"
echo "   iCloud: ~/Library/Mobile Documents/com~apple~CloudDocs/PRISM_Backups/"
