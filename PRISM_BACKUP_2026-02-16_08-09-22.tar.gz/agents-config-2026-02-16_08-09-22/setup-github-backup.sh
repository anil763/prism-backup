#!/bin/bash
# Complete GitHub Backup Setup Script
# Run this AFTER you've:
# 1. Created a private repo at https://github.com/YOUR_USERNAME/prism-backup
# 2. Added SSH key to GitHub (see below)

set -e

REPO_DIR="/Users/anilgunjal/.openclaw/backup/prism-backup-repo"
GITHUB_USERNAME="${1:-}"

if [ -z "$GITHUB_USERNAME" ]; then
  echo "❌ Usage: bash setup-github-backup.sh YOUR_GITHUB_USERNAME"
  echo ""
  echo "First time setup:"
  echo "  1. Go to https://github.com/settings/keys"
  echo "  2. Click 'New SSH key'"
  echo "  3. Paste this entire block:"
  echo ""
  cat ~/.ssh/id_ed25519.pub
  echo ""
  echo "  4. Title: PRISM Backup"
  echo "  5. Click 'Add SSH key'"
  echo "  6. Then run: bash setup-github-backup.sh YOUR_GITHUB_USERNAME"
  exit 1
fi

echo "🔧 Setting up GitHub backup for: $GITHUB_USERNAME"
echo ""

# Configure git to use SSH
git config --global url."git@github.com:".insteadOf "https://github.com/"

cd "$REPO_DIR"

# Add remote
echo "📤 Adding GitHub remote..."
git remote rm origin 2>/dev/null || true
git remote add origin "git@github.com:$GITHUB_USERNAME/prism-backup.git"

# Create .gitignore
echo "⚙️  Creating .gitignore..."
cat > .gitignore << 'EOF'
# Sensitive files
*.key
*.pem
credentials.json
.env
.env.local

# OS files
.DS_Store
Thumbs.db

# Keep backup files
!*.tar.gz
EOF

git add .gitignore
git commit -m "Add .gitignore" || true

# Push
echo "🚀 Pushing to GitHub..."
if git push -u origin main; then
  echo ""
  echo "✅ GitHub backup configured successfully!"
  echo ""
  echo "Repository: https://github.com/$GITHUB_USERNAME/prism-backup"
  echo ""
  echo "Backups will now push to GitHub automatically every day at 5 AM"
  echo ""
else
  echo ""
  echo "❌ Push failed. Troubleshooting:"
  echo "  1. Verify SSH key was added: https://github.com/settings/keys"
  echo "  2. Test connection: ssh -T git@github.com"
  echo "  3. Check repo exists: https://github.com/$GITHUB_USERNAME/prism-backup"
  exit 1
fi
