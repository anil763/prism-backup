#!/bin/bash
# PRISM Backup & Disaster Recovery System
# Backs up all critical files daily to GitHub private repo

BACKUP_DIR="/Users/anilgunjal/.openclaw/backup"
GITHUB_REPO="https://github.com/anil763/prism-backup.git"
TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)

mkdir -p "$BACKUP_DIR"

echo "🔄 Starting PRISM backup ($TIMESTAMP)..."

# 1. Backup agent configs
echo "📋 Backing up agent configs..."
cp -r /Users/anilgunjal/.openclaw/workspace/agents-config "$BACKUP_DIR/agents-config-$TIMESTAMP"

# 2. Backup memory files
echo "📝 Backing up memory files..."
cp -r /Users/anilgunjal/.openclaw/workspace/memory "$BACKUP_DIR/memory-$TIMESTAMP"

# 3. Backup cron jobs (exported from gateway)
echo "⏰ Exporting cron job list..."
mkdir -p "$BACKUP_DIR/cron-jobs"
echo "Cron jobs exported on $TIMESTAMP" > "$BACKUP_DIR/cron-jobs/CRON_BACKUP_$TIMESTAMP.txt"

# 4. Create system manifest (what needs to run on restore)
cat > "$BACKUP_DIR/SYSTEM_MANIFEST.md" << 'MANIFEST'
# PRISM System Manifest - Disaster Recovery

## Critical Infrastructure

### 1. Agents Running
- Daily Revenue Briefing (6 AM EST)
- NEXUS CODE Agent (7 AM EST)
- Perplexity Research Bridge (7 AM EST)
- Spiritual Business Agent (7:45 AM EST)
- AI Trends Agent (8 AM EST)
- UGC Email Agent (6 AM Mon-Fri)
- Managed Services Agent (8:15 AM EST)
- GKANJ Agent (8 AM EST)
- Vault Growth Agent (10 AM EST)
- UGC Optimization Agent (12 PM EST)
- Notes Analyzer Agent (9 AM EST)
- Readings Monetization Agent (6 PM EST)
- Memory Bank Agent (24/7 webhook)
- Weekly Ops Report (Monday 7 AM EST)

### 2. API Keys (Store in env vars)
- Perplexity: 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
- Discord Bot Token: MTQ3MjgwMzU3NTU3Nzk2ODc0MQ.GrWBlC.gi5uj2MsP0RUlNAp-RqdZw4hiGHeOiI9_O-rQ0
- Apollo API: (stored in .env)

### 3. Discord Channels
- #ugc-opportunities: 1472807023497449573
- #spiritual-business: 1472807024759803916
- #ai-trends: 1472807025632084079
- #managed-services: 1472807026668212225
- #memory-bank: 1472808814507069494
- #notes: 1472808824963469416
- #gkanj: 1472814689007304784

### 4. Critical Files
- /agents-config/mission-control.json (agent specs)
- /agents-config/discord-channels.json (channel mappings)
- /agents-config/discord-credentials.json (API config)
- /agents-config/perplexity-research-bridge.sh (research fetcher)
- /memory/ (all memory files)
- Second Brain at anilsbrain.com (backed up to GitHub)

### 5. Recovery Steps
1. Clone this backup repo
2. Restore agents-config/ to ~/.openclaw/workspace/
3. Restore memory/ to ~/.openclaw/workspace/
4. Set environment variables (API keys)
5. Re-create cron jobs (copy job IDs from backup)
6. Verify all agents running

### 6. Testing
- Test backup monthly
- Monthly: Verify all cron jobs still exist
- Weekly: Check that new memory files are backing up

MANIFEST

# 5. Zip everything
echo "📦 Compressing backup..."
cd "$BACKUP_DIR"
tar -czf "PRISM_BACKUP_$TIMESTAMP.tar.gz" agents-config-* memory-* cron-jobs/ SYSTEM_MANIFEST.md
rm -rf agents-config-* memory-* cron-jobs/

echo "✅ Backup complete: $BACKUP_DIR/PRISM_BACKUP_$TIMESTAMP.tar.gz"
echo ""
echo "📤 Pushing to GitHub backup repo..."
git clone $GITHUB_REPO prism-backup-repo 2>/dev/null || true
cd prism-backup-repo
cp "../PRISM_BACKUP_$TIMESTAMP.tar.gz" .
cp ../SYSTEM_MANIFEST.md .
git add .
git commit -m "🔄 PRISM Backup $TIMESTAMP" 2>/dev/null || true
git push origin main 2>/dev/null || true

echo "✅ All systems backed up and pushed to GitHub"
