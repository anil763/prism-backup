#!/bin/bash
# Perplexity Research Bridge
# Fetches research data for all agents before they run
# Saves structured JSON that agents can reference

API_KEY="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"
OUTPUT_DIR="/Users/anilgunjal/.openclaw/workspace/agents-config/research-output"
mkdir -p "$OUTPUT_DIR"

# Function to call Perplexity API
fetch_research() {
  local topic="$1"
  local output_file="$2"
  
  curl -s -X POST "https://api.perplexity.ai/chat/completions" \
    -H "Authorization: Bearer $API_KEY" \
    -H "Content-Type: application/json" \
    -d "{
      \"model\": \"sonar\",
      \"messages\": [{
        \"role\": \"user\",
        \"content\": \"$topic\"
      }],
      \"temperature\": 0.2
    }" | jq -r '.choices[0].message.content' > "$output_file"
}

# Spiritual Business Research
echo "🔍 Fetching Spiritual Business opportunities..."
fetch_research \
  "Find latest trends in spiritual coaching, numerology business models, where spiritual seekers hang out (Reddit, TikTok, Discord, YouTube), pricing for spiritual services, market opportunities for Gen X spiritual entrepreneurs. Include specific communities, pricing data, and competitor offerings." \
  "$OUTPUT_DIR/spiritual-business-research.txt"

# AI Trends Research
echo "🤖 Fetching AI Trends..."
fetch_research \
  "Latest news on: Claude/OpenClaw updates, new LLM releases, AI agent tools, AI in business/productivity, AI controversies or regulations. Include specific tools, release dates, business implications, pricing. Focus on last 48 hours." \
  "$OUTPUT_DIR/ai-trends-research.txt"

# Managed Services Research
echo "☁️ Fetching MSP/Cloud Landscape..."
fetch_research \
  "Latest announcements from AWS, Azure, Google Cloud. Managed services competitor moves, market trends in cloud management, AI integration into cloud services, gaps Presidio could fill. Include specific product launches, pricing, business implications." \
  "$OUTPUT_DIR/managed-services-research.txt"

# Create index file
echo "✅ Research fetched at $(date)" > "$OUTPUT_DIR/index.txt"
echo "" >> "$OUTPUT_DIR/index.txt"
echo "Files ready for agents:" >> "$OUTPUT_DIR/index.txt"
echo "- spiritual-business-research.txt" >> "$OUTPUT_DIR/index.txt"
echo "- ai-trends-research.txt" >> "$OUTPUT_DIR/index.txt"
echo "- managed-services-research.txt" >> "$OUTPUT_DIR/index.txt"

echo "✅ All research fetched and saved"
