# GitHub Backup Setup Instructions

**Status:** Local git repo initialized at `/Users/anilgunjal/.openclaw/backup/prism-backup-repo/`

## Next Steps (1 minute)

### 1. Create GitHub Repository
Go to https://github.com/new
- **Repository name:** `prism-backup`
- **Description:** Encrypted backup of PRISM system configs, memory, and disaster recovery
- **Visibility:** Private
- **Do NOT initialize with README** (we already have one)
- Click "Create repository"

### 2. Add GitHub Remote
After repo is created, run this command:
```bash
cd /Users/anilgunjal/.openclaw/backup/prism-backup-repo
git remote add origin https://github.com/YOUR_USERNAME/prism-backup.git
git branch -M main
```

### 3. Create GitHub Personal Access Token
Go to https://github.com/settings/tokens
- Click "Generate new token (classic)"
- **Token name:** PRISM_BACKUP
- **Expiration:** 90 days
- **Scopes:** Check `repo` (full control of private repositories)
- Copy the token

### 4. Store Token Securely
```bash
# Add to your keychain (macOS)
security add-generic-password -a github_backup -s PRISM_BACKUP -w YOUR_TOKEN_HERE

# Or add to ~/.gitconfig_backup (less secure, but works)
git config --global credential.helper osxkeychain
```

### 5. Test Push
```bash
cd /Users/anilgunjal/.openclaw/backup/prism-backup-repo
git push -u origin main
```

You should see:
```
Enumerating objects: 3, done.
Counting objects: 100% (3/3), done.
Writing objects: 100% (3/3), ...
To https://github.com/YOUR_USERNAME/prism-backup.git
 * [new branch]      main -> main
```

### 6. Verify
Go to https://github.com/YOUR_USERNAME/prism-backup
You should see the README.md file.

## What Happens After Setup

Every day at 5:00 AM:
1. Local backup created: `/Users/anilgunjal/.openclaw/backup/PRISM_BACKUP_*.tar.gz`
2. iCloud Drive updated: `~/Library/Mobile Documents/com~apple~CloudDocs/PRISM_Backups/`
3. GitHub pushed: `github.com/YOUR_USERNAME/prism-backup`

## Recovery

If your iMac crashes:
```bash
# Clone backup from GitHub
git clone https://github.com/YOUR_USERNAME/prism-backup.git
cd prism-backup
tar -xzf PRISM_BACKUP_*.tar.gz
# Restore files to ~/.openclaw/workspace/
```

**Estimated time: 3 minutes to set up, then fully automated.**
