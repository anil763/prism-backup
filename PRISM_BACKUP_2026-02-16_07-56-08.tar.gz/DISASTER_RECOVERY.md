# 🚨 PRISM Disaster Recovery Plan

**Status:** ✅ Active (Daily backups every 5 AM EST)

If your iMac crashes, the entire PRISM system is recoverable from this plan.

---

## What's Backed Up

✅ All agent configurations
✅ All memory files (MEMORY.md + daily notes)
✅ All Discord channel IDs and API credentials
✅ All cron job specs
✅ System architecture & recovery steps

**Backup Location:** GitHub private repo (auto-pushed daily)
**Backup Frequency:** Daily at 5:00 AM EST
**Last Backup:** Check `/Users/anilgunjal/.openclaw/backup/` on iMac

---

## IF THE iMAC CRASHES

### Step 1: Get Another Mac / New Machine
- Restore from Time Machine backup (if available)
- OR: Install macOS fresh, install OpenClaw, proceed to Step 2

### Step 2: Clone the Backup Repo
```bash
git clone https://github.com/anil763/prism-backup.git
cd prism-backup
# Extract latest backup
tar -xzf PRISM_BACKUP_*.tar.gz
```

### Step 3: Restore Critical Files
```bash
# Copy agent configs
cp -r agents-config-*/* ~/.openclaw/workspace/agents-config/

# Copy memory files
cp -r memory-*/* ~/.openclaw/workspace/memory/

# Verify files exist
ls ~/.openclaw/workspace/agents-config/
ls ~/.openclaw/workspace/memory/
```

### Step 4: Set Environment Variables
Create `~/.openclaw/.env` with:
```
PERPLEXITY_API_KEY=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
DISCORD_BOT_TOKEN=MTQ3MjgwMzU3NTU3Nzk2ODc0MQ.GrWBlC.gi5uj2MsP0RUlNAp-RqdZw4hiGHeOiI9_O-rQ0
APOLLO_API_KEY=(from 1Password or password manager)
```

### Step 5: Restart OpenClaw Gateway
```bash
openclaw gateway restart
```

### Step 6: Verify All Cron Jobs Are Running
```bash
cron list
```
Should show 14+ jobs. If any are missing, reference SYSTEM_MANIFEST.md to recreate them.

### Step 7: Test Critical Agents
- Check #ugc-opportunities Discord (UGC Email Agent should have posted)
- Check Telegram for morning briefing
- Verify agents are running on schedule

---

## Critical Information to Know

### API Keys (Keep Safe)
```
Perplexity: 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
Discord Bot: MTQ3MjgwMzU3NTU3Nzk2ODc0MQ.GrWBlC.gi5uj2MsP0RUlNAp-RqdZw4hiGHeOiI9_O-rQ0
Discord Server: 1472794487934812173
```

### Cron Job IDs (Reference for Restore)
```
Daily Revenue Briefing: 5f7f11ec-f723-4cc9-9f68-5df516cd63df
Weekly Ops Report: 50d714b1-c91e-45a2-a720-fec26e11a781
UGC Optimization: 494c6c59-a0f4-4c3e-bed8-f1374901e391
Readings Monetization: 2608f57e-797a-4af8-85b1-cd983532dd84
Vault Growth: bbb70307-d31a-485f-a04e-d7a4db1d745f
NEXUS CODE: 0499bdc8-ab39-405c-9650-a768d75a85cf
GKANJ: b1fbfbe0-c71a-47ca-9927-7aa4676b7d48
Research Bridge: 53b244e5-9643-46ba-8cf0-515ee28e5c31
Backup System: 549f745e-9223-4d64-8571-622c35bed88d
Spiritual Business: 8a967d9d-13d6-42e1-8ce9-679f18b769d9
AI Trends: d8e104a7-f893-471d-89bf-34e78cd9c843
Managed Services: 2dfc8a62-f82f-437d-83ca-556b6658e213
```

### Discord Channels (Reference)
```
#ugc-opportunities: 1472807023497449573
#spiritual-business: 1472807024759803916
#ai-trends: 1472807025632084079
#managed-services: 1472807026668212225
#memory-bank: 1472808814507069494
#notes: 1472808824963469416
#gkanj: 1472814689007304784
```

---

## Expected Recovery Time

| Scenario | Time to Recovery |
|----------|-----------------|
| Hardware replacement + restore | 2-3 hours |
| Fresh macOS install + restore | 4-5 hours |
| Time Machine restore | 30 min - 2 hours |

**Revenue Impact:** 0-48 hours (agents won't run until OpenClaw is back online)

---

## Prevention

### Daily (Automatic)
- ✅ 5:00 AM backup to GitHub (handled by cron job)
- ✅ Second Brain pushed to GitHub (handled by Night Shift Builder)

### Weekly (Manual)
- Test backup extraction (1st Monday of month)
- Verify all cron jobs still exist in gateway
- Check that new memory files are backing up

### Monthly (Manual)
- Full disaster recovery drill (extract backup, verify files)
- Update DISASTER_RECOVERY.md if anything changed
- Test on a different machine if possible

---

## What NOT to Lose

1. **Agent Configs** - All your agent specifications
2. **Memory Files** - All your learnings, decisions, insights
3. **API Keys** - Credentials for Perplexity, Discord, Apollo
4. **Cron Jobs** - The entire schedule that drives revenue
5. **Discord Channel IDs** - Mapping to where agents post

---

## In Case of Emergency

1. **Lost iMac:** Contact GitHub support to access backup repo
2. **Lost GitHub access:** Restore from Time Machine if available
3. **Lost API keys:** Contact Perplexity, Discord, Apollo support to regenerate

---

**Last Updated:** Feb 16, 2026
**Backup Status:** ✅ ACTIVE (5 AM daily)
**Next Backup:** Tomorrow 5 AM EST
